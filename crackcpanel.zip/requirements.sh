#!/bin/bash

# Memperbarui daftar paket
pkg update && pkg upgrade -y

# Menginstal Python dan pip jika belum terinstal
pkg install python -y
pkg install python-pip -y

# Menginstal paket yang diperlukan
pip install requests rich